document.addEventListener('DOMContentLoaded', function() {
  const bookForm = document.getElementById('bookForm');
  const incompleteBookList = document.getElementById('incompleteBookList');
  const completeBookList = document.getElementById('completeBookList');
  const searchBookForm = document.getElementById('searchBook');
  const searchBookTitleInput = document.getElementById('searchBookTitle');

  const STORAGE_KEY = 'BOOKS';

  let books = loadDataFromStorage();
  displayAllBooks();

  function saveDataToStorage() {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(books));
  }

  function loadDataFromStorage() {
    const serializedData = localStorage.getItem(STORAGE_KEY);
    let data = JSON.parse(serializedData);
    return data === null ? [] : data;
  }

  function displayBook(book) {
    const bookItem = document.createElement('div');
    bookItem.setAttribute('data-bookid', book.id);
    bookItem.setAttribute('data-testid', 'bookItem');

    const bookItemTitle = document.createElement('h3');
    bookItemTitle.setAttribute('data-testid', 'bookItemTitle');
    bookItemTitle.textContent = book.title;

    const bookItemAuthor = document.createElement('p');
    bookItemAuthor.setAttribute('data-testid', 'bookItemAuthor');
    bookItemAuthor.textContent = `Penulis: ${book.author}`;

    const bookItemYear = document.createElement('p');
    bookItemYear.setAttribute('data-testid', 'bookItemYear');
    bookItemYear.textContent = `Tahun: ${book.year}`;

    const buttonContainer = document.createElement('div');

    const isCompleteButton = document.createElement('button');
    isCompleteButton.setAttribute('data-testid', 'bookItemIsCompleteButton');
    isCompleteButton.textContent = book.isComplete ? 'Belum selesai dibaca' : 'Selesai dibaca';
    isCompleteButton.addEventListener('click', function() {
      toggleComplete(book.id);
    });

    const deleteButton = document.createElement('button');
    deleteButton.setAttribute('data-testid', 'bookItemDeleteButton');
    deleteButton.textContent = 'Hapus Buku';
    deleteButton.addEventListener('click', function() {
      removeBook(book.id);
    });

    const editButton = document.createElement('button');
        editButton.setAttribute('data-testid', 'bookItemEditButton');
        editButton.textContent = 'Edit Buku';
        editButton.addEventListener('click', function() {
            // TODO: Logic to edit book
        });

    buttonContainer.append(isCompleteButton, deleteButton, editButton);

    bookItem.append(bookItemTitle, bookItemAuthor, bookItemYear, buttonContainer);

    if (book.isComplete) {
      completeBookList.appendChild(bookItem);
    } else {
      incompleteBookList.appendChild(bookItem);
    }
  }

  function toggleComplete(bookId) {
    const bookIndex = findBookIndex(bookId);
    if (bookIndex === -1) return;
    books[bookIndex].isComplete = !books[bookIndex].isComplete;
    saveDataToStorage();
    displayAllBooks();
  }

  function removeBook(bookId) {
    const bookIndex = findBookIndex(bookId);
    if (bookIndex === -1) return;
    books.splice(bookIndex, 1);
    saveDataToStorage();
    displayAllBooks();
  }

  function findBookIndex(bookId) {
    for (let i = 0; i < books.length; i++) {
      if (books[i].id === bookId) return i;
    }
    return -1;
  }

  function displayAllBooks() {
    incompleteBookList.innerHTML = '';
    completeBookList.innerHTML = '';
    for (const book of books) {
      displayBook(book);
    }
  }

  bookForm.addEventListener('submit', function(event) {
    event.preventDefault();
    const bookTitle = document.getElementById('bookFormTitle').value;
    const bookAuthor = document.getElementById('bookFormAuthor').value;
    const bookYear = document.getElementById('bookFormYear').value;
    const bookIsComplete = document.getElementById('bookFormIsComplete').checked;

    const bookId = Date.now();
    const book = {
      id: bookId,
      title: bookTitle,
      author: bookAuthor,
      year: parseInt(bookYear),
      isComplete: bookIsComplete
    };

    books.push(book);
    displayBook(book);
    saveDataToStorage();
    bookForm.reset();
  });

  searchBookForm.addEventListener('submit', function(event) {
    event.preventDefault();
    const searchTerm = searchBookTitleInput.value.toLowerCase();
    const filteredBooks = books.filter(book => book.title.toLowerCase().includes(searchTerm));

    incompleteBookList.innerHTML = '';
    completeBookList.innerHTML = '';
    for (const book of filteredBooks) {
      displayBook(book);
    }
  });
});